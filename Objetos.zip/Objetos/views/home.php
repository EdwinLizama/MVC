

    <main>
        <h1>Bienvenido a mi página principal ROR</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus nisi mollitia eveniet consequuntur maiores? Autem quos, dolorum dolorem dolore adipisci, laudantium et id, mollitia quis nulla totam suscipit? Atque, expedita.</p>
    </main>