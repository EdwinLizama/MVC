
 <?php
 
    echo "hola";
    header('Content-Type: application/json; charset=utf-8');
    echo $arr;
  
  
 ?>


 
 