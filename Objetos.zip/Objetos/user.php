<?php
require_once "render/BaseLayout.php";
BaseLayout::renderHead();
BaseLayout::renderUser();
BaseLayout::renderFoot();