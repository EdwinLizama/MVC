<?php

class About
{
    public function showAbout()
    {
        $aboutDir = "about.php";
        
        return $aboutDir;
    }
}