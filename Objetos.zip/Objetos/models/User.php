<?php


//extraer datos de users.json
//pasarlos a userController y luego a userView
//file put contents




class User
{

    public function showUsers()
    {
        $json = file_get_contents("users.json");
        
        return $json;
    }
}
