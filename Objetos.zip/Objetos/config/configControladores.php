<?php
define ('CONTROLLERS_DIR', "controllers/");
define ('DEFAULT_CONTROLLER', "Home");
define ('DEFAULT_ACTION', "showHome");