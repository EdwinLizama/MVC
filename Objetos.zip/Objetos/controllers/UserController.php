<?php

class UseController
{
    public function showUsers()
    {
        require_once "models/User.php";
        $user = new User();
        $arr = $user->showJson();
        require_once "views/user.php";
      

    }

}

